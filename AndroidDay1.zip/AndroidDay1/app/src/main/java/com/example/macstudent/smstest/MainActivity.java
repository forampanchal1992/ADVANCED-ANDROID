package com.example.macstudent.smstest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.IOException;
import java.util.Iterator;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {


    //OKHttp variable
    OkHttpClient client = new OkHttpClient();

    //user interface variaable
    TextView textviewMain;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //iniatialie
        textviewMain = (TextView) findViewById(R.id.textviewMain);

    }

    //action (click handler) for any button
    public void buttonPressed(View v){
        //OPTION for output
        //System.out.println("Hey Hello");

        //Option2 android logging system
       // Log.d("MyApp","Pressed the button");

        //1.tell teh system what URL u want
       // Request request = new Request.Builder().url("https://jsonplaceholder.typicode.com/todos/1\n").build();
        String URL ="https://api.coindesk.com/v1/bpi/historical/close.json?currency=BRL&start=2018-01-01&end=2018-01-10";
        Request request = new Request.Builder().url(URL).build();

        //2. Send the request to internet and wait for response
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //what should if request get fails
                Log.d("Foram","An error occured");
                e.printStackTrace();  //print whatever error is
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d("Foram","Request Successful");

                if(response.isSuccessful()){
                    //what happens if request was
                    final String reply = response.body().string();

                    //PArse the JSON
                    try{
                        //Make JSON object
                        JSONObject json = new JSONObject(reply);

                        JSONObject bpi = json.getJSONObject("bpi");

                        String disclaimer = json.getString("disclaimer");

                        Log.d("JSON",disclaimer);
                        Log.d("JOSN",bpi.toString());

                        //CALCULATE AVERAGE::::.........

                        int totalitems = bpi.length();
                        double sum = 0;
                        int i =0;

                        Iterator<String> iterator = bpi.keys();

                        while (iterator.hasNext()){
                           // JSONObject item = iterator.next();
                            String key = iterator.next();
                            double price  = bpi.getDouble(key);

                            //addd price to array
                            sum = sum + price;

                           /*
                            Log.d("JSON","Key");
                            Log.d("JOSN",key);

                            Log.d("JSON","Print out item");
                            Log.d("JOSN",Double.toString(price));
                            */



                        }

                        double average = sum /totalitems;
                        Log.d("JOSN","Average:::::");
                        Log.d("AVERAGE",Double.toString((average)));

                        /*
                        //2.parse the stuff inside the object
                        int userId = json.getInt("userId");
                        String title = json.getString("title");
                        boolean done = json.getBoolean("completed");
                        */

                        /*
                        //3.do somewthing
                        Log.d("JSON",Integer.toString(userId));
                        Log.d("JSON",title);
                        Log.d("JOSN",Boolean.toString(done));

                        //4.lets do logic
                        if(done == false){
                            Log.d("JSONPARSER","The system is down");
                        }
                        if(userId == 1){
                            Log.d("JSON",title);
                        }*/

                    }
                    catch (Exception e){
                        Log.d("JSON","Error while json parsing");
                        e.printStackTrace();
                    }

                    /*
                    Log.d("Foram",reply);

                    //3. do something
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //do your user interface nonsense here
                            textviewMain.setText(reply);
                        }
                    });*/
                }
            }
        });

    }
}
