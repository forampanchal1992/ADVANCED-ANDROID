package com.example.macstudent.sms;

import android.Manifest;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

public class MainActivity extends AppCompatActivity {


    //Dexter Variable
    PermissionListener smsPermissionListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createPermissionListener();
    }

    public  void createPermissionListener(){

        //a. function to dseal with permission

        //b. check if persmission listener variable is setup
        if(smsPermissionListener == null){
            smsPermissionListener = new PermissionListener() {
                @Override
                public void onPermissionGranted(PermissionGrantedResponse response) {
                    //what should you do if person picks allow

                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("6476789634",null,"hey what up?",null,null);

                    Log.d("FORAM","SMS SENT!!!!");

                }

                @Override
                public void onPermissionDenied(PermissionDeniedResponse response) {
                    //what should you do if person picks deny

                    Log.d("FORAM","Person picked DENY, I cant send message!!!!");

                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                    //what should you do if permission is already set to deny
                    token.continuePermissionRequest();
                }
            };
        }
        //2. if yes awesome

        //3. if no create it

    }
    //button handler

    public  void smsButtonPressed(View v){

        Log.d("FORAM","Button Pressed");
        //ASK for permission =(show th e popup)
        //--Dexter is automatically going to run
        //createPermissisonListener() function

        Dexter.withActivity(this)
                .withPermission(Manifest.permission.SEND_SMS)
                .withListener(smsPermissionListener)
                .check();

        //code for send SMS
        /*
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage("6476789634",null,"hey what up?",null,null);

        //deal with permission
        Log.d("FORAM","SMS SENT!!!!");*/

    }
}
