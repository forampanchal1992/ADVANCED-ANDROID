package com.example.macstudent.day3;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //Create adapter variable
    private  MyAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //define data for each row in the table
        ArrayList<String> movies = new ArrayList<>();
        movies.add("3 idiots");
        movies.add("Deadpool 2");
        movies.add("Gangs of Wassaypur");
        movies.add("Go Goa Gone");
        movies.add("Garam Masala");
        movies.add("Black Panther");


        //a whole bunch of UI nonsense to make
        //the thing appear properly

        RecyclerView recyclerView = findViewById(R.id.my_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        LinearLayoutManager mlm = (LinearLayoutManager) recyclerView.getLayoutManager();

        mAdapter = new MyAdapter(this, movies);
       // mAdapter.setClickListener(this);
        recyclerView.setAdapter(mAdapter);

    }

}
