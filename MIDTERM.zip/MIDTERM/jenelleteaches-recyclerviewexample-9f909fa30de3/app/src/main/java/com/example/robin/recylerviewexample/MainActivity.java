package com.example.robin.recylerviewexample;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity{


    //OKHttp variable
    OkHttpClient client = new OkHttpClient();

    private MyAdapter mAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String URL ="https://api.darksky.net/forecast/5f3148ab9ac69dac2edfa78ae7e57b08/45.4215,-75.6972?exclude=currently,minutely,hourly,alerts,flags";
        Request request = new Request.Builder().url(URL).build();



        Log.d("JENELLE", "THE APP HAS STARTED!");

        Request q = new Request.Builder()
                .url(URL)
                .build();

        Log.d("JENELLE", "making the call asyncro...");


        client.newCall(q).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d("JENELLE", "failed!");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d("WEATHER", "success!!");

                if (response.isSuccessful()) {
                    final String reply = response.body().string();
            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try{
                        //Make JSON object
                        JSONObject json = new JSONObject(reply);

                        JSONObject daily = json.getJSONObject("daily");
                        String conditions = daily.getString("data");


                        Log.d("HARSH", String.valueOf(conditions));

                        JSONArray t = new JSONArray(conditions);
                      // JSONObject tt = t.getJSONObject(0);
//                        String htemp = tt.getString("temperatureHigh");
//                        String ltemp = tt.getString(
//                                "temperatureLow");
//
//                        Log.d("temp_high",htemp);
//
//                        Log.d("temp_low",ltemp);

                      //  JSONArray jsonarray = new JSONArray(t);
                        Log.d("JSON ARRAY","ghf" + t);
                        for (int i = 1; i < t.length(); i++) {
                            JSONObject jsonobject = t.getJSONObject(i);
//                            String name = jsonobject.getString("name");
//                            String url = jsonobject.getString("url");

                            JSONObject tt = t.getJSONObject(i);

                        String htemp = tt.getString("temperatureHigh");
                        String ltemp = tt.getString(
                                "temperatureLow");

                        Log.d("temp_high",htemp);

                     //   Log.d("temp_low",ltemp);
                        }

//
                    }
                    catch (Exception e){
                        Log.d("JSON","Error while json parsing");
                        e.printStackTrace();
                    }

                    Log.d("JENELLE", reply);
                }
            });
                    //PArse the JSON

                }
                else {
                    Log.d("JENELLE", "there was a problem with the response");
                }


            }
        });

    }


    // Click handler for when person clicks on a row
//    @Override
//    public void onItemClick(View view, int position) {
//        Toast.makeText(this, "You clicked " + mAdapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
//    }

}
